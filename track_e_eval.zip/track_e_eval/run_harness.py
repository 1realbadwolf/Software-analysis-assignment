"""Track E harness: DeepEval custom metric over the REAL localGPT Verifier (LLM groundedness checker).
Usage (from the localGPT repo root, Ollama running):
    python track_e_eval/run_harness.py --model qwen3.5:4b --out results_run1.json
    python track_e_eval/run_harness.py --model qwen3.5:4b --out results_run2.json --baseline results_run1.json
"""
import os; os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT","YES")
import argparse, asyncio, json, pathlib, sys, collections
sys.path.insert(0, os.getcwd())
from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase

GOLDEN = pathlib.Path(__file__).with_name("golden_verifier.jsonl")

class VerdictMatch(BaseMetric):
    """Pass when the verifier's is_grounded verdict equals the human label."""
    def __init__(self, threshold: float = 1.0):
        self.threshold = threshold; self.async_mode = False
    def measure(self, test_case: LLMTestCase, *a, **k) -> float:
        got = json.loads(test_case.actual_output)
        want = test_case.expected_output == "grounded"
        self.score = 1.0 if got["is_grounded"] == want else 0.0
        self.success = self.score >= self.threshold
        self.reason = f"verifier said grounded={got['is_grounded']} (conf {got['confidence']}); label grounded={want}"
        return self.score
    async def a_measure(self, test_case, *a, **k): return self.measure(test_case)
    def is_successful(self): return self.success
    @property
    def __name__(self): return "Verdict Match"

def get_verifier(model):
    from rag_system.utils.ollama_client import OllamaClient
    from rag_system.agent.verifier import Verifier
    return Verifier(OllamaClient(host=os.getenv("OLLAMA_HOST","http://localhost:11434")), model)

def run(verifier, cases):
    rows = []
    for c in cases:
        r = asyncio.run(verifier.verify_async(c["query"], c["context"], c["answer"]))
        tc = LLMTestCase(input=c["query"], retrieval_context=[c["context"]],
                         actual_output=json.dumps({"is_grounded": r.is_grounded, "confidence": r.confidence_score}),
                         expected_output="grounded" if c["expected_grounded"] else "ungrounded")
        m = VerdictMatch(); m.measure(tc)
        rows.append(dict(id=c["id"], category=c["category"], expected_grounded=c["expected_grounded"],
                         got_grounded=r.is_grounded, confidence=r.confidence_score, passed=m.success, reason=m.reason))
    return rows

def summarise(rows):
    n = len(rows); ok = sum(r["passed"] for r in rows)
    bad  = [r for r in rows if not r["expected_grounded"]]
    good = [r for r in rows if r["expected_grounded"]]
    by = collections.defaultdict(lambda: [0,0])
    for r in rows: by[r["category"]][1]+=1; by[r["category"]][0]+=r["passed"]
    return dict(
        n=n, accuracy=ok/n,
        hallucination_catch_rate=sum(not r["got_grounded"] for r in bad)/len(bad),      # ungrounded answers correctly rejected
        false_accept_count=sum(r["got_grounded"] for r in bad),                          # hallucinations that slipped through
        false_reject_rate=sum(not r["got_grounded"] for r in good)/len(good),            # good answers wrongly rejected
        unusable_output_rate=sum(r["confidence"]==0 for r in rows)/n,                    # confidence 0 = parse failure / fail-open
        injection_resilience=(lambda s:(sum(r["passed"] for r in s)/len(s)) if s else None)([r for r in rows if r["category"]=="injection"]),
        by_category={k:f"{v[0]}/{v[1]}" for k,v in by.items()})

def main(verifier=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen3.5:4b"); ap.add_argument("--out", default="results.json")
    ap.add_argument("--baseline"); ap.add_argument("--max-drop", type=float, default=0.05)
    a = ap.parse_args()
    cases = [json.loads(l) for l in GOLDEN.read_text().splitlines() if l.strip()]
    rows = run(verifier or get_verifier(a.model), cases); s = summarise(rows)
    json.dump(dict(model=a.model, summary=s, rows=rows), open(a.out,"w"), indent=1)
    print(f"\nModel {a.model}: accuracy {s['accuracy']:.1%} | hallucination catch {s['hallucination_catch_rate']:.1%} "
          f"| false-accept {s['false_accept_count']} | false-reject {s['false_reject_rate']:.1%} "
          f"| unusable {s['unusable_output_rate']:.1%} | injection resilience {s['injection_resilience']:.1%}")
    print("by category:", s["by_category"])
    for r in rows:
        if not r["passed"]: print("  FAIL", r["id"], r["category"], "-", r["reason"])
    if a.baseline:
        b = json.load(open(a.baseline))["summary"]; drop = b["accuracy"]-s["accuracy"]
        print(f"\nPrompt-regression check vs {a.baseline}: baseline {b['accuracy']:.1%} -> now {s['accuracy']:.1%}")
        if drop > a.max_drop: print(f"REGRESSION: accuracy fell {drop:.1%} (> {a.max_drop:.0%})"); sys.exit(1)
        print("No regression beyond tolerance.")
if __name__ == "__main__": main()
