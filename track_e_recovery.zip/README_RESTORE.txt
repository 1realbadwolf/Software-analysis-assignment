COMP 441 TRACK E — COLAB RECOVERY BUNDLE
==========================================

Contents:
  tests/test_filters.py                 Original AI-generated tests (46; known errors)
  tests/test_filters_reviewed.py        Reviewed v1 mutation tests (46)
  tests/test_filters_mutation_v2.py     Mutation-strengthened v2 tests (54)

IMPORTANT:
- This bundle restores TEST CODE, not the lost Colab virtual machine.
- The Mutmut cache/database and complete v1/v2 statistics are NOT included.
- The original baseline file intentionally contains the known AI-generated errors.
- Run pytest on one chosen suite at a time; don't run a plain 'pytest' across all three.
- Keep production code unchanged.

1. In a CPU Colab notebook, run:

    %cd /content
    !git clone https://github.com/PromtEngineer/localGPT.git
    !pip install -q pytest pytest-cov mutmut

If localGPT already exists, skip git clone.

2. Upload track_e_recovery.zip (download from the ChatGPT answer) and extract:

    from google.colab import files
    from pathlib import Path
    from zipfile import ZipFile
    uploaded = files.upload()
    archive_name = "track_e_recovery.zip"
    assert archive_name in uploaded, "Choose track_e_recovery.zip"
    with ZipFile(archive_name) as z:
        for name in ("tests/test_filters.py", "tests/test_filters_reviewed.py", "tests/test_filters_mutation_v2.py"):
            dest = Path("/content/localGPT") / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(name))
    print("Test files restored")

3. Verify tests:

    %cd /content/localGPT
    !python -m pytest tests/test_filters_reviewed.py -q
    !python -m pytest tests/test_filters_mutation_v2.py -q

The previous run reported 46 and 54 passing respectively, but verify in the newly cloned source revision.

4. To measure v2 coverage:

    !python -m pytest tests/test_filters_mutation_v2.py --cov=rag_system.retrieval.filters --cov-branch --cov-report=term-missing

5. To rerun mutation testing, configure [tool.mutmut] in /content/localGPT/pyproject.toml:

    [tool.mutmut]
    source_paths = ["rag_system/retrieval/filters.py"]
    pytest_add_cli_args_test_selection = ["tests/test_filters_reviewed.py"]

Then run `!mutmut run` and `!mutmut results`, save v1 stats. Change selection to
`tests/test_filters_mutation_v2.py`; rerun `!mutmut run` and `!mutmut results`.
Do not assume that a surviving-mutant count by itself is a mutation score.

6. SAVE TO GOOGLE DRIVE OR DOWNLOAD YOUR FILES BEFORE DISCONNECTING.
Files under /content are temporary and are not shared between CPU/GPU runtimes.
